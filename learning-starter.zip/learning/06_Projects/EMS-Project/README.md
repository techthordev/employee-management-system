# EMS Project

## Overview
- Fullstack project: Spring Boot backend + Angular frontend
- PostgreSQL database with public and auth schemas
- Docker/Podman compose for dev environment

## Lessons Learned
- Test endpoints after creating controllers
- Keep init SQL scripts idempotent
- Document API early with Swagger
