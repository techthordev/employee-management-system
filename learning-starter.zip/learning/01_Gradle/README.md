# Gradle Setup

## Build & Run
- Build project: ./gradlew build
- Run project: ./gradlew bootRun

## Best Practices
- Use Kotlin DSL (build.gradle.kts) for new projects
- Keep build scripts clean and organized
- Manage dependencies carefully
